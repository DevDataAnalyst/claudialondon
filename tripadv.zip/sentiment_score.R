# combined model performance
#Model 1
cat("model 1 ")
library("utils", lib.loc="C:/Personal/R/R-3.4.1/library")
library('RSentiment')
library('tm')
library('sentimentr')
library("textstem", lib.loc="C:/Personal/R/R-3.4.1/library")
library("stringr", lib.loc="C:/Personal/R/R-3.4.1/library")
library("sentiment", lib.loc="C:/Personal/R/R-3.4.1/library")
library("Rstem", lib.loc="C:/Personal/R/R-3.4.1/library")

#Twitter

# LOAD DATA FROM CSV
#dat1 = reviews

dat1 = read.csv("C:\\Personal\\misctasks\\tripadv\\reviews.csv",header=TRUE)


dat1$stripped_text <- gsub("http.*","",  dat1$text)
dat1$stripped_text = gsub("@\\w+ *", "", dat1$stripped_text)
dat1$stripped_text = gsub("<\\w+ *", "", dat1$stripped_text)
dat1$stripped_text =  gsub("[[:punct:]]","", dat1$stripped_text)
#dat1$stripped_text =  gsub("[[:digit:]]","", dat1$stripped_text)
x = as.data.frame(dat1$stripped_text)
colnames(x) = "text"
##### text file export

tweets = dat1$stripped_text
tweets = as.data.frame(tweets)
r1 = tweets

r1$CleanText <- ""


# Text preprocessing function
Clean_String <- function(string){
  #symbol replace
  temp = str_replace_all(string, "[^[:alnum:]]", " ")
  # Lowercase
  temp <- tolower(string)
  # Remove everything that is not a number or letter 
  temp <- str_replace_all(temp,"[^a-zA-Z\\s]", " ")
  # Remove stopwords
  temp <- removeWords(temp, stopwords('en'))
  # Shrink down to just one white space
  temp <- str_replace_all(temp,"[\\s]+", " ")
  # Split the string into words
  #temp <- str_split(temp, " ")[[1]]
  temp <- stem_words(temp)
  # Get rid of trailing "" if necessary
  indexes <- which(temp == "")
  if(length(indexes) > 0){temp <- temp[-indexes]}
  # Get unique words
  return(paste(unique(temp),collapse = ' '))
}  

#Clean all the texts row-wise

for(i in 1:NROW(r1))
{
  r1$CleanText[i] <- Clean_String(r1$text[i])
}  

#Sentiment Calculation and compiling within one dataframe

textdata = tweets[c("tweets")]
sentiment_scores = classify_polarity(r1)
Sentiment = as.data.frame(sentiment_scores[,3:4])
final_result = cbind(textdata,Sentiment)
colnames(final_result)= c("Tweets","Ratio","Polarity")

final_result = cbind(final_result,dat1[,4:6])

write.csv(final_result, "C:\\Personal\\misctasks\\tripadv\\sentiments.csv", row.names = F)
