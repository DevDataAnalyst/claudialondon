# combined model performance
#Model 1
cat("model 1 ")
library("utils", lib.loc="C:/Personal/R/R-3.4.1/library")
library('RSentiment')
library('tm')
library('sentimentr')
library("textstem", lib.loc="C:/Personal/R/R-3.4.1/library")
library("stringr", lib.loc="C:/Personal/R/R-3.4.1/library")
library("sentiment", lib.loc="C:/Personal/R/R-3.4.1/library")
library("Rstem", lib.loc="C:/Personal/R/R-3.4.1/library")

#Twitter

# LOAD DATA FROM CSV
#dat1 = reviews

dat1 = read.csv("C:\\Personal\\misctasks\\tripadv\\reviews.csv",header=TRUE)


dat1$stripped_text <- gsub("http.*","",  dat1$text)
dat1$stripped_text = gsub("@\\w+ *", "", dat1$stripped_text)
dat1$stripped_text = gsub("<\\w+ *", "", dat1$stripped_text)
dat1$stripped_text =  gsub("[[:punct:]]","", dat1$stripped_text)
#dat1$stripped_text =  gsub("[[:digit:]]","", dat1$stripped_text)
x = as.data.frame(dat1$stripped_text)
colnames(x) = "text"
##### text file export

tweets = dat1$stripped_text
tweets = as.data.frame(tweets)
r1 = tweets

r1$CleanText <- ""


# Text preprocessing function
Clean_String <- function(string){
  #symbol replace
  temp = str_replace_all(string, "[^[:alnum:]]", " ")
  # Lowercase
  temp <- tolower(string)
  # Remove everything that is not a number or letter 
  temp <- str_replace_all(temp,"[^a-zA-Z\\s]", " ")
  # Remove stopwords
  temp <- removeWords(temp, stopwords('en'))
  # Shrink down to just one white space
  temp <- str_replace_all(temp,"[\\s]+", " ")
  # Split the string into words
  #temp <- str_split(temp, " ")[[1]]
  temp <- stem_words(temp)
  # Get rid of trailing "" if necessary
  indexes <- which(temp == "")
  if(length(indexes) > 0){temp <- temp[-indexes]}
  # Get unique words
  return(paste(unique(temp),collapse = ' '))
}  

#Clean all the texts row-wise

for(i in 1:NROW(r1))
{
  r1$CleanText[i] <- Clean_String(r1$text[i])
}  

#Sentiment Calculation and compiling within one dataframe

textdata = tweets[c("tweets")]
sentiment_scores = classify_polarity(r1)
Sentiment = as.data.frame(sentiment_scores[,3:4])
final_result = cbind(textdata,Sentiment)
colnames(final_result)= c("Tweets","Ratio","Polarity")

final_result = cbind(final_result,dat1[,4:6])


#### dividing positive and negative reviews

X <- split(final_result, final_result$Polarity)
neg = X$negative
pos = X$positive


#attach(pos)

pos$Ratio = as.numeric(levels(pos$Ratio))[pos$Ratio]
pos <- pos[rev(order(pos$Ratio)),]

#attach(neg)

neg$Ratio = as.numeric(levels(neg$Ratio))[neg$Ratio]
neg <- neg[rev(order(neg$Ratio)),]


######################
write.csv(final_result, "C:\\Personal\\misctasks\\tripadv\\sentiments.csv", row.names = F)

### positive and Negative wordcloud

write.csv(pos, "C:\\Personal\\misctasks\\tripadv\\positive.csv", row.names = F)
write.csv(neg, "C:\\Personal\\misctasks\\tripadv\\negative.csv", row.names = F)

### Positive and negative Word Clouds
### POSITIVE

library('qdap')
p1 = Corpus(VectorSource(pos$Tweets))
dtm <- DocumentTermMatrix(p1)
p1 <- tolower(p1)
p1 <- removePunctuation(p1)
p1 <- removeNumbers(p1)
p1 = removeWords(p1, stopwords('en'))
p1 = gsub('\\b\\w{1,7}\\b','',p1)
pos_top_words = freq_terms(p1,top = 50)   # based on complete text, Top 20 words

write.csv(pos_top_words, "C:\\Personal\\misctasks\\tripadv\\pos_wordcloud.csv", row.names = F)

### NEGATIVE


library('qdap')
n1 = Corpus(VectorSource(neg$Tweets))
dtm <- DocumentTermMatrix(n1)
n1 <- tolower(n1)
n1 <- removePunctuation(n1)
n1 <- removeNumbers(n1)
n1 = removeWords(n1, stopwords('en'))
n1 = gsub('\\b\\w{1,7}\\b','',n1)
neg_top_words = freq_terms(n1,top = 50)   # based on complete text, Top 20 words
neg_scores = classify_polarity(neg_top_words$WORD)

write.csv(pos_top_words, "C:\\Personal\\misctasks\\tripadv\\neg_wordcloud.csv", row.names = F)


### emotional context


textdata = tweets[c("tweets")]
sentiment_scores = classify_emotion(r1)
Sentiment = as.data.frame(sentiment_scores[,7])
emo_result = cbind(textdata,Sentiment)
colnames(emo_result)= c("Tweets","Polarity")


write.csv(emo_result, "C:\\Personal\\misctasks\\tripadv\\emo_result.csv", row.names = F, heade)


