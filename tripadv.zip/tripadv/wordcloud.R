
library("utils", lib.loc="C:/Personal/R/R-3.4.1/library")
library('RSentiment')
library('tm')
library('qdap')
library('sentimentr')
library("textstem", lib.loc="C:/Personal/R/R-3.4.1/library")
library("stringr", lib.loc="C:/Personal/R/R-3.4.1/library")
library("sentiment", lib.loc="C:/Personal/R/R-3.4.1/library")
library("Rstem", lib.loc="C:/Personal/R/R-3.4.1/library")

# LOAD DATA FROM CSV
Sample_data <- read.csv("C:\\Personal\\misctasks\\tripadv\\reviews.csv",header=TRUE)
tweets = Sample_data

r1 = tweets

r1$CleanText <- ""


# Text preprocessing function
Clean_String <- function(string){
  #symbol replace
  temp = str_replace_all(string, "[^[:alnum:]]", " ")
  # Lowercase
  temp <- tolower(string)
  # Remove everything that is not a number or letter 
  temp <- str_replace_all(temp,"[^a-zA-Z\\s]", " ")
  # Remove stopwords
  temp <- removeWords(temp, stopwords('en'))
  # Shrink down to just one white space
  temp <- str_replace_all(temp,"[\\s]+", " ")
  # Split the string into words
  temp <- str_split(temp, " ")[[1]]
  temp <- stem_words(temp)
  #temp = str_replace(temp,"[:alpha:]{2,5}?", " ")
  # Get rid of trailing "" if necessary
  indexes <- which(temp == "")
  if(length(indexes) > 0){temp <- temp[-indexes]}
  # Get unique words
  return(paste(unique(temp),collapse = ' '))
}  


textdata= tweets[,c("text")]


for(i in 1:NROW(r1))
{
  r1$CleanText[i] <- Clean_String(r1$text[i])
}


s1 = Corpus(VectorSource(r1$text))
dtm <- DocumentTermMatrix(s1)
s1 <- tolower(s1)
s1 <- removePunctuation(s1)
s1 <- removeNumbers(s1)
s1 = removeWords(s1, stopwords('en'))
s1 = gsub('\\b\\w{1,7}\\b','',s1)
top_words = freq_terms(s1,top = 750)   
 

write.csv(top_words, "C:\\Personal\\misctasks\\tripadv\\wordcloud.csv", row.names = F)


##### Positive


#textdata = tweets[c("tweets")]
sentiment_scores = classify_polarity(top_words$WORD)
Sentiment = as.data.frame(sentiment_scores[,3:4])
sent_word = cbind(top_words,Sentiment)
colnames(sent_word)= c("WORD","FREQ","Ratio","Polarity")

X <- split(sent_word, sent_word$Polarity)
neg = X$negative
pos = X$positive


write.csv(pos, "C:\\Personal\\misctasks\\tripadv\\pos_wordcloud.csv", row.names = F)
write.csv(neg, "C:\\Personal\\misctasks\\tripadv\\neg_wordcloud.csv", row.names = F)

##### Negative

dataset = data.frame(tweets[,2])
colnames(dataset) = c("text")

library(stringr)
getCount <- function(data,keyword)
{
  wcount <- str_count(dataset$text, keyword)
  return(data.frame(data,wcount))
}

context = getCount(dataset,word)


word = c('room','lunch','food','bar','service')

