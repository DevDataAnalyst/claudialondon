
library(data.table)
library(ggplot2)

df = read.csv(file.choose(),header = TRUE)

attach(df)


colnames(df)[1] <- "Date"
colnames(df)[6] <- "ChangePercent"

attach(df)

df$Price <- as.numeric(gsub(",","",df$Price))
df$Open <- as.numeric(gsub(",","",df$Open))
df$High <- as.numeric(gsub(",","",df$High))

df$Date <- strptime(x = as.character(df$Date),format = "%d/%m/%Y")


# Price of Bitcoin as a Time Series Graph
ggplot(data=df, aes(x=Date, y=Price, group=1)) +
  geom_line(color="red")+
  geom_point()


# Change Percentages
ggplot(data=df, aes(x=Date, y=ChangePercent, group=1)) +
  geom_line(color="Blue")+
  geom_point()





